import asyncio
import os

from dotenv import load_dotenv

from database import engine
from scheduler_engine import dispatch_due
from mailer import Mailer

load_dotenv()


async def main():

    mailer = Mailer(
        host=os.getenv("SMTP_HOST"),
        port=int(os.getenv("SMTP_PORT")),
        username=os.getenv("SMTP_USER"),
        password=os.getenv("SMTP_PASS")
    )

    while True:

        with engine.begin() as db:

            await dispatch_due(
                db,
                mailer
            )

        print("Worker tick...")

        await asyncio.sleep(15)


if __name__ == "__main__":

    asyncio.run(main())