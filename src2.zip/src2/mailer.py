import email.utils
import aiosmtplib

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


class Mailer:

    def __init__(
        self,
        host,
        port,
        username,
        password
    ):

        self.host = host
        self.port = port
        self.username = username
        self.password = password

    async def send_html(
        self,
        from_name,
        from_email,
        to_email,
        subject,
        html
    ):

        msg = MIMEMultipart()

        msg["From"] = email.utils.formataddr(
            (from_name, from_email)
        )

        msg["To"] = to_email
        msg["Subject"] = subject

        msg.attach(
            MIMEText(html, "html")
        )

        try:

            smtp = aiosmtplib.SMTP(
                hostname=self.host,
                port=self.port,
                use_tls=True
            )

            await smtp.connect()

            await smtp.login(
                self.username,
                self.password
            )

            await smtp.send_message(msg)

            await smtp.quit()

            return {"ok": True}

        except Exception as e:

            return {
                "ok": False,
                "error": str(e)
            }