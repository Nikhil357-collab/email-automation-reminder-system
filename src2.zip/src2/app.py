from fastapi import FastAPI
from pydantic import BaseModel, EmailStr

from sqlalchemy import text

import uuid
import datetime as dt

from database import engine

app = FastAPI()


class Contact(BaseModel):
    name: str
    email: EmailStr
    timezone: str = "Asia/Kolkata"


class Template(BaseModel):
    name: str
    subject: str
    body_md: str


class Campaign(BaseModel):
    name: str
    template_id: str
    sender_name: str
    sender_email: EmailStr


class Reminder(BaseModel):
    title: str
    contact_id: str
    campaign_id: str
    start_at_utc: str
    rrule: str | None = None


@app.get("/")
def home():

    return {
        "message": "Email Automation API Running"
    }


@app.post("/contacts")
def create_contact(c: Contact):

    with engine.begin() as db:

        cid = str(uuid.uuid4())

        db.execute(text("""
            INSERT INTO contacts(
                id,
                name,
                email,
                timezone
            )
            VALUES(
                :i,
                :n,
                :e,
                :tz
            )
        """), dict(
            i=cid,
            n=c.name,
            e=c.email,
            tz=c.timezone
        ))

        return {"id": cid}


@app.post("/templates")
def create_template(t: Template):

    with engine.begin() as db:

        tid = str(uuid.uuid4())

        db.execute(text("""
            INSERT INTO templates(
                id,
                name,
                subject,
                body_md,
                created_at
            )
            VALUES(
                :i,
                :n,
                :s,
                :b,
                :ts
            )
        """), dict(
            i=tid,
            n=t.name,
            s=t.subject,
            b=t.body_md,
            ts=dt.datetime.utcnow()
        ))

        return {"id": tid}